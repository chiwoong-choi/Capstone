// 📌 1️⃣ 페이지 로드 시 사용자 목록 불러오기
document.addEventListener("DOMContentLoaded", function () {
    fetchUsers();  // 페이지가 로드되면 사용자 목록을 불러옴
});

// 📌 2️⃣ Flask 서버에서 사용자 데이터 가져오기 (GET 요청)
function fetchUsers() {
    fetch("/api/users")  // Flask 서버의 API 호출
        .then(response => response.json())  // JSON 데이터로 변환
        .then(users => {
            console.log("📢 받은 데이터:", users);  // ✅ 터미널에서 데이터 확인
            if (users.length === 0) {
                console.warn("⚠️ 사용자 데이터가 없습니다.");
                return;
            }

            // 📌 3️⃣ HTML 테이블 업데이트
            const tableBody = document.getElementById("user-table");
            tableBody.innerHTML = "";  // 기존 데이터 초기화
            users.forEach(user => {
                const row = `<tr>
                    <td>${user.id}</td>
                    <td>${user.name}</td>
                    <td>${user.email}</td>
                    <td>****</td>  <!-- 비밀번호는 보이지 않도록 처리 -->
                    <td>${user.age}</td>
                    <td>${user.height}</td>
                    <td>${user.weight}</td>
                </tr>`;
                tableBody.innerHTML += row;
            });
        })
        .catch(error => console.error("❌ 데이터 불러오기 오류:", error));
}

// 📌 4️⃣ 사용자 추가 (POST 요청)
document.getElementById("addUserForm").addEventListener("submit", function (event) {
    event.preventDefault();  // 기본 동작 방지 (페이지 새로고침 X)

    // 📌 5️⃣ 입력값 가져오기
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const age = parseInt(document.getElementById("age").value, 10);
    const height = parseFloat(document.getElementById("height").value);
    const weight = parseFloat(document.getElementById("weight").value);

    // 📌 6️⃣ 데이터 유효성 검사
    if (!name || !email || !password || isNaN(age) || isNaN(height) || isNaN(weight)) {
        alert("⚠️ 모든 입력값을 올바르게 입력해주세요.");
        return;
    }

    // 📌 7️⃣ JSON 데이터 생성
    const userData = { name, email, password, age, height, weight };

    // 📌 8️⃣ Flask 서버로 데이터 전송 (POST 요청)
    fetch("/api/add_user", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(userData)
    })
    .then(response => response.json())
    .then(data => {
        console.log("📢 응답 메시지:", data);
        alert(data.message || "✅ 사용자 추가 완료!");  // 사용자에게 알림 표시
        fetchUsers();  // 사용자 목록 새로고침
    })
    .catch(error => console.error("❌ 사용자 추가 오류:", error));
});