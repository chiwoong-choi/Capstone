import sqlite3
import os

# 📌 데이터베이스 경로 설정 (Flask에서 올바른 위치를 참조하도록 설정)
db_path = os.path.abspath("fitness.db")
print(f"📢 생성할 데이터베이스 경로: {db_path}")

# 📌 SQLite 데이터베이스 연결
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# 📌 `users` 테이블 생성 (없으면 자동 생성)
cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        age INTEGER,
        height REAL,
        weight REAL
    )
""")
conn.commit()
print("✅ `users` 테이블이 생성되었습니다!")

# 📌 샘플 데이터 삽입
sample_data = [
    ("홍길동", "hong1@example.com", "1234", 25, 175.5, 70.0),
    ("김철수", "kim2@example.com", "5678", 30, 180.0, 75.0),
    ("이영희", "lee3@example.com", "abcd", 28, 165.0, 55.0)
]

cursor.executemany("INSERT INTO users (name, email, password, age, height, weight) VALUES (?, ?, ?, ?, ?, ?)", sample_data)
conn.commit()
print("✅ 샘플 데이터가 추가되었습니다!")

# 📌 `users` 테이블 데이터 확인
cursor.execute("SELECT * FROM users;")
rows = cursor.fetchall()
print("📢 users 테이블 데이터:")
for row in rows:
    print(row)

# 📌 연결 종료
conn.close()
print("✅ 데이터베이스 초기화 완료!")