from flask import Flask, request, jsonify
import sqlite3

app = Flask(__name__)

# ✅ 사용자 데이터 조회 함수
def get_users():
    try:
        conn = sqlite3.connect("fitness.db")
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users")
        users = cursor.fetchall()
        conn.close()

        print("📢 DB 데이터:", users)  # 서버 콘솔에서 데이터 확인
        return users

    except Exception as e:
        print("❌ DB 조회 오류:", e)
        return []

# ✅ 기본 페이지 (HTML 직접 반환)
@app.route("/")
def index():
    return """
    <!DOCTYPE html>
    <html lang="ko">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Fitness Users</title>
        <link rel="stylesheet" href="/style.css">  <!-- Flask가 제공하는 CSS -->
    </head>
    <body>
        <h1>🏋️‍♂️ 사용자 목록</h1>
        <table>
            <thead>
                <tr>
                    <th>ID</th><th>이름</th><th>이메일</th><th>나이</th><th>키(cm)</th><th>몸무게(kg)</th>
                </tr>
            </thead>
            <tbody id="user-table">
            </tbody>
        </table>

        <h2>➕ 사용자 추가</h2>
        <form id="addUserForm">
            <input type="text" id="name" placeholder="이름" required>
            <input type="email" id="email" placeholder="이메일" required>
            <input type="password" id="password" placeholder="비밀번호" required>
            <input type="number" id="age" placeholder="나이" required>
            <input type="number" id="height" placeholder="키(cm)" required>
            <input type="number" id="weight" placeholder="몸무게(kg)" required>
            <button type="submit">사용자 추가</button>
        </form>

        <script src="/script.js"></script>  <!-- Flask가 제공하는 JS -->
    </body>
    </html>
    """

# ✅ 사용자 목록 API (JSON 응답)
@app.route("/api/users")
def api_users():
    try:
        users = get_users()
        if not users:
            return jsonify([])  # 🔹 빈 배열 반환하여 오류 방지

        user_list = [
            {"id": u[0], "name": u[1], "email": u[2], "age": u[4], "height": u[5], "weight": u[6]}
            for u in users
        ]
        return jsonify(user_list)

    except Exception as e:
        print("❌ JSON 변환 오류:", e)
        return jsonify({"error": "서버 내부 오류"}), 500

# ✅ 사용자 추가 API (POST 요청)
@app.route("/api/add_user", methods=["POST"])
def add_user():
    try:
        data = request.json
        name, email, password, age, height, weight = (
            data.get("name"), data.get("email"), data.get("password"),
            data.get("age"), data.get("height"), data.get("weight")
        )

        if not all([name, email, password, age, height, weight]):
            return jsonify({"error": "❌ 모든 필드를 입력해야 합니다."}), 400

        conn = sqlite3.connect("fitness.db")
        cursor = conn.cursor()

        # 🔹 users 테이블 존재 확인
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='users'")
        table_exists = cursor.fetchone()
        if not table_exists:
            return jsonify({"error": "❌ 'users' 테이블이 존재하지 않습니다."}), 500

        cursor.execute("""
            INSERT INTO users (name, email, password, age, height, weight)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (name, email, password, age, height, weight))
        conn.commit()
        conn.close()

        return jsonify({"message": "✅ 사용자 추가 완료!"}), 201
    except sqlite3.IntegrityError:
        return jsonify({"error": "❌ 이미 존재하는 이메일입니다."}), 400
    except Exception as e:
        print("❌ 사용자 추가 오류:", e)
        return jsonify({"error": f"❌ 서버 내부 오류: {str(e)}"}), 500

# ✅ JavaScript 파일 서빙 (script.js)
@app.route("/script.js")
def serve_js():
    js_code = """
    document.addEventListener("DOMContentLoaded", function () {
        console.log("📢 JavaScript 파일이 정상적으로 로드되었습니다!");

        function fetchUsers() {
            fetch("/api/users")
                .then(response => response.json())
                .then(users => {
                    console.log("📢 받은 데이터:", users);
                    
                    if (!Array.isArray(users)) {
                        console.error("❌ 데이터가 배열이 아님:", users);
                        return;
                    }

                    const tableBody = document.getElementById("user-table");
                    tableBody.innerHTML = ""; // 기존 데이터 초기화

                    users.forEach(user => {
                        const row = document.createElement("tr");
                        row.innerHTML = `
                            <td>${user.id}</td>
                            <td>${user.name}</td>
                            <td>${user.email}</td>
                            <td>${user.age}</td>
                            <td>${user.height}</td>
                            <td>${user.weight}</td>
                        `;
                        tableBody.appendChild(row);
                    });
                })
                .catch(error => console.error("❌ 데이터 불러오기 오류:", error));
        }

        fetchUsers();

        document.getElementById("addUserForm").addEventListener("submit", function (event) {
            event.preventDefault();

            const name = document.getElementById("name").value;
            const email = document.getElementById("email").value;
            const password = document.getElementById("password").value;
            const age = document.getElementById("age").value;
            const height = document.getElementById("height").value;
            const weight = document.getElementById("weight").value;

            fetch("/api/add_user", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ name, email, password, age, height, weight })
            })
            .then(response => response.json())
            .then(data => {
                console.log("✅ 사용자 추가 결과:", data);
                alert(data.message || data.error);
                fetchUsers();  // 사용자 목록 새로고침
            })
            .catch(error => console.error("❌ 사용자 추가 오류:", error));
        });
    });
    """
    return js_code, 200, {"Content-Type": "application/javascript"}

# ✅ CSS 파일 서빙 (style.css)
@app.route("/style.css")
def serve_css():
    css_code = """
    body {
        font-family: Arial, sans-serif;
        background-color: #f5f5f5;
        margin: 20px;
        padding: 20px;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    th, td {
        border: 1px solid #ddd;
        padding: 10px;
        text-align: left;
    }
    th {
        background-color: #007BFF;
        color: white;
    }
    form {
        margin-top: 20px;
    }
    input, button {
        margin: 5px;
        padding: 10px;
    }
    """
    return css_code, 200, {"Content-Type": "text/css"}

if __name__ == "__main__":
    app.run(debug=True)